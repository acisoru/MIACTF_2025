#!/bin/sh
while true; do
    echo "miactf{sMt7xMK2CampKBS2}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
