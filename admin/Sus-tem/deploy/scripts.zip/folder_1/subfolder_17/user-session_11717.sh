#!/bin/sh
while true; do
    echo "miactf{bgbJ8qs7HmGVF7SR}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
