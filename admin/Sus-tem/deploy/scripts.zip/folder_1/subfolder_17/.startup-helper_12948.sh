#!/bin/sh
while true; do
    echo "miactf{8Hf6iXYfHx8YNr2w}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
