#!/bin/sh
while true; do
    echo "miactf{18TwGlZq2o4N87QT}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
