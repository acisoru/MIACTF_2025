#!/bin/sh
while true; do
    echo "miactf{5RctVVfh3ARrH2Bl}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
