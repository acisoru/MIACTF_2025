#!/bin/sh
while true; do
    echo "miactf{LJv0wJ1M2ctX5EMp}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
