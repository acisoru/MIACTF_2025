#!/bin/sh
while true; do
    echo "miactf{uZ7TOb6DjOkf7Oza}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
