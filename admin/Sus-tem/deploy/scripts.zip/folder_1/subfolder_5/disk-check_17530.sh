#!/bin/sh
while true; do
    echo "miactf{9WVgOuS7THvCQ4vS}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
