#!/bin/sh
while true; do
    echo "miactf{ppzLP1RsQ7FU7f51}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
