#!/bin/sh
while true; do
    echo "miactf{DuAk6N65L7qrx25y}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
