#!/bin/sh
while true; do
    echo "miactf{Pw2wqAbt5l8qLsww}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
