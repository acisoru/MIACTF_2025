#!/bin/sh
while true; do
    echo "miactf{IwiLeXirbwRq8OXM}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
