#!/bin/sh
while true; do
    echo "miactf{Be3U0Swr4oAUCCr2}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
