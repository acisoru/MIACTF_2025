#!/bin/sh
while true; do
    echo "miactf{NKHeiSG82OwPmypf}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
