#!/bin/sh
while true; do
    echo "miactf{ahPp1lSSa2WZz4i1}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
