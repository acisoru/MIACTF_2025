#!/bin/sh
while true; do
    echo "miactf{1Nb3phn1xecp4CVh}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
