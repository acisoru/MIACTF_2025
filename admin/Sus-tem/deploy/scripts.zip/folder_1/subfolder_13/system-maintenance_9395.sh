#!/bin/sh
while true; do
    echo "miactf{qgf5FTnG1c5QMV7F}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
