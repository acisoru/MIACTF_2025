#!/bin/sh
while true; do
    echo "miactf{5jZsi8jTf7Dt0eGl}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
