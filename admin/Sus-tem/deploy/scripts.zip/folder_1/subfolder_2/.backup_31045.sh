#!/bin/sh
while true; do
    echo "miactf{4N9E6g1HGiuio4zH}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
