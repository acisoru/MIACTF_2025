#!/bin/sh
while true; do
    echo "miactf{1Do40V0oNzRD6LA4}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
