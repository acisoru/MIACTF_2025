#!/bin/sh
while true; do
    echo "miactf{k6k7EXQ16RvU5X5X}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
