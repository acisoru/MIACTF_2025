#!/bin/sh
while true; do
    echo "miactf{xxQ4VmFZBRW6hVEw}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
