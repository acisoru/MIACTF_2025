#!/bin/sh
while true; do
    echo "miactf{FazPMCYNd1p53wh1}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
