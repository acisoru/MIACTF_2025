#!/bin/sh
while true; do
    echo "miactf{G9y9ZswmvsP64RbK}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
