#!/bin/sh
while true; do
    echo "miactf{wqi5kzcZDfA4TNYl}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
