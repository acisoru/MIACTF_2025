#!/bin/sh
while true; do
    echo "miactf{JOtNoZZwwb0Z8Z9W}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
