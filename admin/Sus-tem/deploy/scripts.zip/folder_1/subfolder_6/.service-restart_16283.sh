#!/bin/sh
while true; do
    echo "miactf{Eu5zz0ZWvl1PUJfn}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
