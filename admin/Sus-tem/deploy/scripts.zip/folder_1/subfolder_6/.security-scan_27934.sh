#!/bin/sh
while true; do
    echo "miactf{B5R6TMHnGnG90lpF}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
