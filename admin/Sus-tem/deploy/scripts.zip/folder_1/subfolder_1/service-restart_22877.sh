#!/bin/sh
while true; do
    echo "miactf{c5YpJ9ccmPov03eX}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
