#!/bin/sh
while true; do
    echo "miactf{RHS0aVRNhgQ8XsM3}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
