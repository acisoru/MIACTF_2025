#!/bin/sh
while true; do
    echo "miactf{58S5Dsz8E1EU9O74}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
