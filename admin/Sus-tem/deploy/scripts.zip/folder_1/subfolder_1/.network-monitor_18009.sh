#!/bin/sh
while true; do
    echo "miactf{d2SWw398PQGvv6CI}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
