#!/bin/sh
while true; do
    echo "miactf{uowHBJoX3t2d4Gjr}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
