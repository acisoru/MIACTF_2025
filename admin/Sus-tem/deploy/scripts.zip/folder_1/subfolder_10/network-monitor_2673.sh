#!/bin/sh
while true; do
    echo "miactf{pUYAeU330fOmIdeC}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
