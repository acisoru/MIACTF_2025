#!/bin/sh
while true; do
    echo "miactf{b9elsOgl99Q0sumZ}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
