#!/bin/sh
while true; do
    echo "miactf{EP7VUfAe9B91xBzr}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
