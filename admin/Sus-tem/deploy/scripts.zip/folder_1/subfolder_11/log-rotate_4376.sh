#!/bin/sh
while true; do
    echo "miactf{bCY45Wghv6uUr39X}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
