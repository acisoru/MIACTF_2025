#!/bin/sh
while true; do
    echo "miactf{sCGo1Jq7m8hslGvb}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
