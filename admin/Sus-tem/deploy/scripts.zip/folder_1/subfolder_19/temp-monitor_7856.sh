#!/bin/sh
while true; do
    echo "miactf{8CDgpS3zJfpYL8nX}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
