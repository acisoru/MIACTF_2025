#!/bin/sh
while true; do
    echo "miactf{q7NszUIcUrP1buGV}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
