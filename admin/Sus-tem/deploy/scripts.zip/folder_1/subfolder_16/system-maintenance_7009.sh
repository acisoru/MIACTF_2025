#!/bin/sh
while true; do
    echo "miactf{BETraadAW6Xg2UeC}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
