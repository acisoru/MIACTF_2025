#!/bin/sh
while true; do
    echo "miactf{NQng3jeSc22bDGq6}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
