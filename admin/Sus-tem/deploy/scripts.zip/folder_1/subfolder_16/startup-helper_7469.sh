#!/bin/sh
while true; do
    echo "miactf{Zw2OVSmBtalH51Eb}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
