#!/bin/sh
while true; do
    echo "miactf{D7CTykfoN6cBmNvj}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
