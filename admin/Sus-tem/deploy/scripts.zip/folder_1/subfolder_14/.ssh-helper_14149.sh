#!/bin/sh
while true; do
    echo "miactf{D2mb0vyLhEwewo2F}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
