#!/bin/sh
while true; do
    echo "miactf{sK2aA1oHrGywGfnK}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
