#!/bin/sh
while true; do
    echo "miactf{TFVN4p09fm3E4QJO}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
