#!/bin/sh
while true; do
    echo "miactf{mDgKTrSPixo4c05t}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
