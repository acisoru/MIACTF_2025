#!/bin/sh
while true; do
    echo "miactf{jUujM2B4SM17VQ4g}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
