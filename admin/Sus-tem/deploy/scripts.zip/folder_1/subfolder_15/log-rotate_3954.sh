#!/bin/sh
while true; do
    echo "miactf{JGE3cTxeeaN6wAlv}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
