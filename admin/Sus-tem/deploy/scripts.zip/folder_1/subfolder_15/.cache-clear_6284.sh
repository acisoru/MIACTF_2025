#!/bin/sh
while true; do
    echo "miactf{pDKsY05I6Px6wrt4}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
