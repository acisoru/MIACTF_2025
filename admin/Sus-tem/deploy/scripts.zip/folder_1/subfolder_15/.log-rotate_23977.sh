#!/bin/sh
while true; do
    echo "miactf{GZifLloXRv4HlBIX}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
