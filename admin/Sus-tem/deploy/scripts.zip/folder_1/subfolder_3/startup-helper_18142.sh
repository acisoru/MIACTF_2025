#!/bin/sh
while true; do
    echo "miactf{vr6YK5CNXZXVruqA}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
