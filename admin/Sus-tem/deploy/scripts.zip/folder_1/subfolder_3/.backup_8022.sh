#!/bin/sh
while true; do
    echo "miactf{n3N7euOaAV5YEZWw}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
