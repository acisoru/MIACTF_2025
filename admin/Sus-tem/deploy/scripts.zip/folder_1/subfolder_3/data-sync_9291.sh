#!/bin/sh
while true; do
    echo "miactf{J4c0X9APtLsOaopx}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
