#!/bin/sh
while true; do
    echo "miactf{jnj2NYUkhC3v2CIA}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
