#!/bin/sh
while true; do
    echo "miactf{Vi5gg5GnQrs65Im6}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
