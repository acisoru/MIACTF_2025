#!/bin/sh
while true; do
    echo "miactf{FVG56glJ8V89vhgE}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
