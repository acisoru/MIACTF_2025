#!/bin/sh
while true; do
    echo "miactf{CkzC2GUTZ9tG9CCA}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
