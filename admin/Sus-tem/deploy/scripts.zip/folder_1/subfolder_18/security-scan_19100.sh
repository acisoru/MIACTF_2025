#!/bin/sh
while true; do
    echo "miactf{wL5xZxUlKs9JaMRq}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
