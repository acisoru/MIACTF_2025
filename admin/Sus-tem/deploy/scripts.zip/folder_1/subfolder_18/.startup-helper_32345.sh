#!/bin/sh
while true; do
    echo "miactf{7wxz7KyI1NqwZeue}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
