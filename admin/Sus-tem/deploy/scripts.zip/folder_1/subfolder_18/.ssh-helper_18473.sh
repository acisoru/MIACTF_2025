#!/bin/sh
while true; do
    echo "miactf{fw9CReNFjIZUNGKa}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
