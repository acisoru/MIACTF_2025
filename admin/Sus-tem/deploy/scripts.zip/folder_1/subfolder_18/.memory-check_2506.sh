#!/bin/sh
while true; do
    echo "miactf{sycizA2kfpuEZ18D}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
