#!/bin/sh
while true; do
    echo "miactf{myY7Ys7iiDcfJHV9}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
