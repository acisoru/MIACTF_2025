#!/bin/sh
while true; do
    echo "miactf{8BhDJRtGrBixM1ic}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
