#!/bin/sh
while true; do
    echo "miactf{we1QQwFL4vDSDLEq}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
