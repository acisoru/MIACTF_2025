#!/bin/sh
while true; do
    echo "miactf{OD8Zocagc5gzqsPb}"
    sleep 1
    echo "Running system check..."
    sleep 1
    echo "System task completed."
    sleep 1
done
